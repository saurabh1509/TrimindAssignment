package com.trimind.payment.tracer.app.entities;

public class user {

}
