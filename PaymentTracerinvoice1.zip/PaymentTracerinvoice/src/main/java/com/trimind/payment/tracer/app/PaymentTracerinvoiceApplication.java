package com.trimind.payment.tracer.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentTracerinvoiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentTracerinvoiceApplication.class, args);
	}

}
